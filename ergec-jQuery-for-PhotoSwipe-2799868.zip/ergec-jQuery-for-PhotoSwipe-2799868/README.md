#jQuery Wrapper for [PhotoSwipe](https://github.com/dimsemenov/photoswipe)

This plugin will allow you to easily transition from your existing fancybox/lightbox plugins to PhotoSwipe without altering you HTML layout or finding a way define image dimensions. Plugin gets your existing html layout and creates all structure needed for [PhotoSwipe](https://github.com/dimsemenov/photoswipe).

##Usage

Visit https://ergec.github.io/jQuery-for-PhotoSwipe/ for details
